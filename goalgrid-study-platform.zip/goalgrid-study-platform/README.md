# goalgrid study platform

A Pen created on CodePen.

Original URL: [https://codepen.io/azra-moh/pen/jEMQyGj](https://codepen.io/azra-moh/pen/jEMQyGj).

